//
//  CoverViewCell.swift
//  Slider...
//
//  Created by macbookUser on 25/04/18.
//  Copyright © 2018 macbookUser. All rights reserved.
//

import UIKit

class CoverViewCell: UICollectionViewCell{
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupLayout()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    let imageCover: UIImageView = {
        let iv = UIImageView()
        iv.image = UIImage(named: "blackwatch")
        iv.contentMode = .scaleToFill
        return iv
    }()
    
    let etiqueta: UILabel = {
        let label = UILabel()
        label.text = "Blackwatch en las sombras"
        label.font = UIFont.systemFont(ofSize: 13)
        label.numberOfLines = 2
        return label
    }()
    
    func setupLayout(){
        addSubview(imageCover)
        addSubview(etiqueta)
        
        imageCover.frame = CGRect(x: 0, y: 0, width: frame.width, height: frame.width)
        etiqueta.frame = CGRect(x: 0, y: frame.width + 2, width: frame.width, height: 40)
    }
    
}
