//
//  LoginViewController.swift
//  LoginDiplomado
//
//  Created by macbookUser on 09/05/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor.green

        // Do any additional setup after loading the view.
    }

}
