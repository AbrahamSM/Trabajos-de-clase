//
//  ViewController.swift
//  LoginDiplomado
//
//  Created by Germán Santos Jaimes on 5/3/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

class ViewController: UIViewController {
    
    var ref: DatabaseReference!
    
    // Creamos nuestra area donde pondremos la forma de registro
    let formContainerView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.white
        view.translatesAutoresizingMaskIntoConstraints = false
        view.layer.cornerRadius = 5
        view.layer.masksToBounds = true
        return view
    }()
    
    let registerButton: UIButton = {
        let button = UIButton(type: .system)
        button.backgroundColor = UIColor(red: 232/255, green: 173/255, blue: 72/255, alpha: 1.0)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(UIColor.white, for: .normal )
        button.setTitle("Registro", for: .normal)
        
        // parte 2, hacemos grande la letra del boton
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        
        // parte 2 cuando es UX
        button.layer.cornerRadius = 5
        button.layer.masksToBounds = true
        
        button.addTarget(self, action: #selector(loginRegister), for: .touchUpInside)
        
        return button
    }()
    
//    let nameTextField: UITextField = {
//        let tf = UITextField()
//        tf.placeholder = "Nombre"
//        tf.translatesAutoresizingMaskIntoConstraints = false
//
//        return tf
//    }()
    
    let emailTextField: UITextField = {
        let tf = UITextField()
        tf.placeholder = "Correo electrónico"
        tf.translatesAutoresizingMaskIntoConstraints = false
        
        return tf
    }()
    
    let passwordTextField: UITextField = {
        let tf = UITextField()
        tf.placeholder = "Contraseña"
        tf.translatesAutoresizingMaskIntoConstraints = false
        tf.isSecureTextEntry = true
        return tf
    }()
    
    // Parte 4
    lazy var formSegmentedControl: UISegmentedControl = {
        let sc = UISegmentedControl(items: ["Login", "Registro"])
        sc.translatesAutoresizingMaskIntoConstraints = false
        sc.tintColor = UIColor.white
        sc.selectedSegmentIndex = 1
        
        // parte 2 - 1
        sc.addTarget(self, action: #selector(algopaso), for: .valueChanged )
        return sc
    }()
    
    

    @objc func algopaso(){
        let title = formSegmentedControl.titleForSegment(at: formSegmentedControl.selectedSegmentIndex)
        registerButton.setTitle(title, for: .normal)
        print(formSegmentedControl.selectedSegmentIndex)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.init(red: 30/255, green: 62/255, blue: 106/255, alpha: 1.0)
        
        view.addSubview(formContainerView)
        view.addSubview(registerButton)
        view.addSubview(formSegmentedControl)
       
        // Ahora el nameTextfield, este va dentro del formview
//        formContainerView.addSubview(nameTextField)
        formContainerView.addSubview(emailTextField)
        formContainerView.addSubview(passwordTextField)
        
        

        formContainerView.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        formContainerView.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        formContainerView.widthAnchor.constraint(equalTo: view.widthAnchor, constant: -20).isActive = true
        formContainerView.heightAnchor.constraint(equalToConstant: 120).isActive = true
        
        
        // setup button
        registerButton.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        registerButton.topAnchor.constraint(equalTo: formContainerView.bottomAnchor, constant: 15).isActive = true
        

        registerButton.widthAnchor.constraint(equalTo: formContainerView.widthAnchor).isActive = true
        registerButton.heightAnchor.constraint(equalToConstant: 50).isActive = true
        

//        nameTextField.leftAnchor.constraint(equalTo: formContainerView.leftAnchor, constant: 10).isActive = true
//        nameTextField.topAnchor.constraint(equalTo: formContainerView.topAnchor).isActive = true
//        nameTextField.widthAnchor.constraint(equalTo: formContainerView.widthAnchor).isActive = true
//        nameTextField.heightAnchor.constraint(equalToConstant: 60).isActive = true
        
        emailTextField.leftAnchor.constraint(equalTo: formContainerView.leftAnchor, constant: 10).isActive = true
        emailTextField.topAnchor.constraint(equalTo: formContainerView.topAnchor).isActive = true
        emailTextField.widthAnchor.constraint(equalTo: formContainerView.widthAnchor).isActive = true
        emailTextField.heightAnchor.constraint(equalToConstant: 60).isActive = true
        
        passwordTextField.leftAnchor.constraint(equalTo: formContainerView.leftAnchor, constant: 10).isActive = true
        passwordTextField.topAnchor.constraint(equalTo: emailTextField.bottomAnchor).isActive = true
        passwordTextField.widthAnchor.constraint(equalTo: formContainerView.widthAnchor).isActive = true
        passwordTextField.heightAnchor.constraint(equalToConstant: 60).isActive = true
        
       
        // Segmented control
        formSegmentedControl.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        formSegmentedControl.bottomAnchor.constraint(equalTo: formContainerView.topAnchor, constant: -20).isActive = true
        formSegmentedControl.widthAnchor.constraint(equalTo: formContainerView.widthAnchor).isActive = true
        formSegmentedControl.heightAnchor.constraint(equalToConstant: 50).isActive = true
        
        ref = Database.database().reference()
    }
    
    @objc func loginRegister(){
        
        if formSegmentedControl.selectedSegmentIndex == 0{
            loginUser()
        }else{
            registerUser()
        }
        
    }
    
    func registerUser(){
        if let email = emailTextField.text, let password = passwordTextField.text{
            Auth.auth().createUser(withEmail: email, password: password) { (user, error) in
                if user != nil{
                    print("Usuario creado")
                    
                    let values = ["email": email]
                    let uid = user?.uid
                    
                    let usersReference = self.ref.child("users").child(uid!)
                    
                    
                    usersReference.updateChildValues(values, withCompletionBlock: {
                        (error, databaseRef) in
                        if error != nil{
                            print("error al insertar datos")
                            return
                        }
                        
                        print("Se insertaron los datos")
                    })
                    
                    let login = LoginViewController()
                    self.navigationController?.pushViewController(login, animated: true)
                    
                    
                }else{
                    if let error = error?.localizedDescription {
                        print("Hubo un error por firebase", error)
                    }else{
                        print("El error eres tu")
                    }
                }
            }
        }
    }
    
    func loginUser(){
        if let email = emailTextField.text, let password = passwordTextField.text{
            Auth.auth().signIn(withEmail: email, password: password) { (user, error) in
                if user != nil{
                    print("Usuario autenticado ")
                }else{
                    if let error = error?.localizedDescription {
                        print("Hubo un error por firebase", error)
                    }else{
                        print("El error eres tu")
                    }
                }
            }
        }
    }
    
}
